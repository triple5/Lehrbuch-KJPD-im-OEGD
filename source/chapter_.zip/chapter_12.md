---
layout: page
title: c. Impressum
nav_order: 12
---
 
<details markdown="block"> 
  <summary> 
      &#9658; Inhaltsverzeichnis Kapitel (ausklappbar) 
  </summary>
 
1. TOC
{:toc}
 </details>
 
   <p></p>
 
 
Der Sozialpsychiatrische Dienst

Lehrbuch für den Öffentlichen Gesundheitsdienst

ISBN 978-3-9812871-6-5

DOI

Datum 2020

Ort Berlin

<div class="section fnlist" data-role="doc-footnotes">

</div>
